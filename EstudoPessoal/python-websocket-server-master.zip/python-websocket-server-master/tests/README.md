Testing
--------

Run unit tests

    pytest


Run functional tests

     python message_lengths.py

Open client.html in the browser and refresh consequently until all test cases pass.
