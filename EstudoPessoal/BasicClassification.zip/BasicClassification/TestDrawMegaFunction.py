# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 14:04:25 2018

@author: lcristovao
"""

import DrawMegaFunction as dm
import pandas as pd
import numpy as np




#____________________Main________________________________

#Irish dataset
# Load dataset from site
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = pd.read_csv(url, names=names)


predictor=dm.ReturnPredictor(dataset)

#_____________________________________________________________________


# Load dataset from site
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/pima-indians-diabetes/pima-indians-diabetes.data"
'''
    1. Number of times pregnant
   2. Plasma glucose concentration a 2 hours in an oral glucose tolerance test
   3. Diastolic blood pressure (mm Hg)
   4. Triceps skin fold thickness (mm)
   5. 2-Hour serum insulin (mu U/ml)
   6. Body mass index (weight in kg/(height in m)^2)
   7. Diabetes pedigree function
   8. Age (years)
   9. Class variable (0 or 1)
'''
names = ['Number-of-times-pregnant', 'Plasma-glucose-concentration', 'Diastolic-blood-pressure', 'Triceps-skin-fold-thickness', 'serum-insulin','Body-mass-index ','Diabetes-pedigree-function','Age','Diabetes']
dataset = pd.read_csv(url, names=names)
dataset.describe()
#Missing values in this dataset are zeros where it does not make sence
##Invalid zero minimal value:
#1: Plasma glucose concentration
#2: Diastolic blood pressure
#3: Triceps skinfold thickness
#4: 2-Hour serum insulin
#5: Body mass index
#these are de columns 1,2,3,4,5 

#Lets find number of zeros of each of these columns
print((dataset.iloc[:,1:6] == 0).sum())
#In pandas is easy to detect and replace missing values if they are NaN so we need
#to replace zeros to NaN with function replace
# mark zero values as missing or NaN
dataset.iloc[:,1:6] = dataset.iloc[:,1:6].replace(0, np.NaN)
# count the number of NaN values in each column
print(dataset.isnull().sum())
# fill missing values with mean column values
dataset.fillna(dataset.mean(), inplace=True)
# count the number of NaN values in each column
print(dataset.isnull().sum())

predictor=dm.ReturnPredictor(dataset)

#____________________________________________________________________________

url = "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data"
'''
age: continuous. 
workclass: Private, Self-emp-not-inc, Self-emp-inc, Federal-gov, Local-gov, State-gov, Without-pay, Never-worked. 
fnlwgt: continuous. 
education: Bachelors, Some-college, 11th, HS-grad, Prof-school, Assoc-acdm, Assoc-voc, 9th, 7th-8th, 12th, Masters, 1st-4th, 10th, Doctorate, 5th-6th, Preschool. 
education-num: continuous. 
marital-status: Married-civ-spouse, Divorced, Never-married, Separated, Widowed, Married-spouse-absent, Married-AF-spouse. 
occupation: Tech-support, Craft-repair, Other-service, Sales, Exec-managerial, Prof-specialty, Handlers-cleaners, Machine-op-inspct, Adm-clerical, Farming-fishing, Transport-moving, Priv-house-serv, Protective-serv, Armed-Forces. 
relationship: Wife, Own-child, Husband, Not-in-family, Other-relative, Unmarried. 
race: White, Asian-Pac-Islander, Amer-Indian-Eskimo, Other, Black. 
sex: Female, Male. 
capital-gain: continuous. 
capital-loss: continuous. 
hours-per-week: continuous. 
native-country: United-States, Cambodia, England, Puerto-Rico, Canada, Germany, Outlying-US(Guam-USVI-etc), India, Japan, Greece, South, China, Cuba, Iran, Honduras, Philippines, Italy, Poland, Jamaica, Vietnam, Mexico, Portugal, Ireland, France, Dominican-Republic, Laos, Ecuador, Taiwan, Haiti, Columbia, Hungary, Guatemala, Nicaragua, Scotland, Thailand, Yugoslavia, El-Salvador, Trinadad&Tobago, Peru, Hong, Holand-Netherlands.
'''
names = ['age', 'workclass', 'fnlwgt', 'education', 'education-num', 
         'marital-status','occupation','relationship','race','sex',
         'capital-gain', 'capital-loss','hours-per-week','native-country',
         'class']
dataset = pd.read_csv(url, names=names)

predictor=dm.ReturnPredictor(dataset)